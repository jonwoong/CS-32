#include "Board.h"
#include "Game.h"
#include "Player.h"
#include "Side.h"

using namespace std;

int main()
{
    return 0;
}